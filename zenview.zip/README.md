# ZenView

Hide YouTube distractions with customizable keyboard shortcuts for focused viewing.

## Usage

Click the extension icon or press Ctrl+Shift+F to toggle distraction-free mode on any YouTube video.